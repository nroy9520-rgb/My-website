# Images Folder

Place your image files here.

Supported formats:
- .jpg / .jpeg
- .png
- .gif
- .svg
- .webp

Example usage in HTML:
```html
<img src="images/logo.png" alt="Logo">
```
